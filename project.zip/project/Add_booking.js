$(function() {
    $( "#datepicker" ).datepicker({
    numberOfMonths: 1,
    minDate:0,
    showButtonPanel: true,      
    });
});